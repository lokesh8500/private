﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="register.aspx.vb" Inherits="register" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Student Registration</title>
</head>

<body>
    <form id="form1" runat="server">

        <div>

            <h1>Student Registration</h1>

            <asp:Label ID="Label1" runat="server" Text="Username"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label2" runat="server" Text="Password"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox2" runat="server"
                TextMode="Password"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label3" runat="server" Text="Name"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox3" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label4" runat="server" Text="Email"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox4" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label5" runat="server" Text="Mobile"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox5" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label6" runat="server" Text="Address"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox6" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label7" runat="server" Text="City"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox7" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label8" runat="server" Text="State"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox8" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label9" runat="server" Text="Marks"></asp:Label>
            <br />
            <asp:TextBox ID="TextBox9" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Button ID="Button1" runat="server"
                Text="Register" />

            <br /><br />

            <asp:LinkButton ID="LinkButton1" runat="server">
                Back to Login
            </asp:LinkButton>

        </div>

    </form>
</body>
</html>