﻿<%@ Page Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="maritlist.aspx.vb" Inherits="maritlist" Title="Marit List" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="head"
    Runat="Server">
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="ContentPlaceHolder1"
    Runat="Server">

    <asp:SqlDataSource ID="SqlDataSource1" runat="server"
        ConnectionString="<%$ ConnectionStrings:Database2ConnectionString %>"
        SelectCommand="SELECT [name], [stream], [marks] FROM [student] ORDER BY [marks] DESC">
    </asp:SqlDataSource>

    <asp:GridView ID="GridView1" runat="server"
        DataSourceID="SqlDataSource1"
        Width="495px"
        AutoGenerateColumns="False">

        <Columns>

            <asp:BoundField DataField="name"
                HeaderText="name"
                SortExpression="name" />

            <asp:BoundField DataField="stream"
                HeaderText="stream"
                SortExpression="stream" />

            <asp:BoundField DataField="marks"
                HeaderText="marks"
                SortExpression="marks" />

        </Columns>

    </asp:GridView>

</asp:Content>