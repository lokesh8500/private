﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class _default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\studAdmiSite\App_Data\Database2.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("select count(username) from student where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'", cn)

        cn.Open()

        Dim count = cmd.ExecuteScalar()

        cn.Close()

        If count > 0 Then

            Session("un") = TextBox1.Text

            Response.Redirect("~/stream.aspx")

        Else

            MsgBox("Invalid username or password")

        End If

    End Sub


    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles LinkButton1.Click

        Response.Redirect("~/register.aspx")

    End Sub

End Class