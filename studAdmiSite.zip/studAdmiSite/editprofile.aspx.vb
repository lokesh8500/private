﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class editprofile
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\studAdmiSite\App_Data\Database2.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("update student set " + "name='" + TextBox1.Text + "',email='" + TextBox2.Text + "',mobile='" + TextBox3.Text + "',address='" + TextBox4.Text + "',city='" + TextBox5.Text + "',state='" + TextBox6.Text + "',marks='" + TextBox7.Text + "' where username='" + Session("un") + "'", cn)

        cn.Open()

        Dim chk As Integer = cmd.ExecuteNonQuery()

        cn.Close()

        If chk = 1 Then

            MsgBox("Your information updated successfully")

        Else

            MsgBox("Some error occurred. Try again")

        End If

    End Sub

End Class