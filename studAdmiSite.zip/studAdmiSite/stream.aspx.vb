﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class stream
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\studAdmiSite\App_Data\Database2.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("update student set stream='" + DropDownList1.Text + "' where username='" + Session("un") + "'", cn)

        cn.Open()

        Dim chk As Integer = cmd.ExecuteNonQuery()

        cn.Close()

        If chk = 1 Then

            MsgBox("Stream selected successfully")

            Response.Redirect("~/maritlist.aspx")

        Else

            MsgBox("Some error occurred")

        End If

    End Sub

End Class