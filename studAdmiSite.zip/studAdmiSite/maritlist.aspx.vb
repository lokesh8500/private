﻿Partial Class maritlist

    Inherits System.Web.UI.Page

End Class
