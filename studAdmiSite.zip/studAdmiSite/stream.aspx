﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="stream.aspx.vb" Inherits="stream" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Stream Selection</title>
</head>

<body>
    <form id="form1" runat="server">

        <div>

            <h1>Stream Selection</h1>

            <asp:Label ID="Label1" runat="server"
                Text="Select Stream"></asp:Label>

            <br /><br />

            <asp:DropDownList ID="DropDownList1" runat="server">

                <asp:ListItem>BCA</asp:ListItem>
                <asp:ListItem>BBA</asp:ListItem>
                <asp:ListItem>BCOM</asp:ListItem>
                <asp:ListItem>BA</asp:ListItem>

            </asp:DropDownList>

            <br /><br />

            <asp:Button ID="Button1" runat="server"
                Text="Save Stream" />

        </div>

    </form>
</body>
</html>