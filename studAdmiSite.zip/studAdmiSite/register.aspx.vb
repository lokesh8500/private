﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class register
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\studAdmiSite\App_Data\Database2.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("insert into student values(@username,@password,@name,@email,@mobile,@address,@city,@state,@marks,@stream)", cn)

        cmd.Parameters.AddWithValue("@username", TextBox1.Text)
        cmd.Parameters.AddWithValue("@password", TextBox2.Text)
        cmd.Parameters.AddWithValue("@name", TextBox3.Text)
        cmd.Parameters.AddWithValue("@email", TextBox4.Text)
        cmd.Parameters.AddWithValue("@mobile", TextBox5.Text)
        cmd.Parameters.AddWithValue("@address", TextBox6.Text)
        cmd.Parameters.AddWithValue("@city", TextBox7.Text)
        cmd.Parameters.AddWithValue("@state", TextBox8.Text)
        cmd.Parameters.AddWithValue("@marks", TextBox9.Text)
        cmd.Parameters.AddWithValue("@stream", "")

        cn.Open()

        cmd.ExecuteNonQuery()

        MsgBox("Registration Successful")

        cn.Close()

        Response.Redirect("~/default.aspx")

    End Sub


    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles LinkButton1.Click

        Response.Redirect("~/default.aspx")

    End Sub

End Class