﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="default.aspx.vb" Inherits="_default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Student Admission System - Login</title>
</head>

<body>
    <form id="form1" runat="server">

        <div>

            <h1>Student Admission System</h1>

            <asp:Label ID="Label1" runat="server" Text="Username"></asp:Label>
            <br />

            <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
            <br /><br />

            <asp:Label ID="Label2" runat="server" Text="Password"></asp:Label>
            <br />

            <asp:TextBox ID="TextBox2" runat="server"
                TextMode="Password"></asp:TextBox>
            <br /><br />

            <asp:Button ID="Button1" runat="server"
                Text="Login" />

            <br /><br />

            <asp:Label ID="Label3" runat="server"
                Text="New Student?"></asp:Label>

            <asp:LinkButton ID="LinkButton1" runat="server">
                Register
            </asp:LinkButton>

        </div>

    </form>
</body>
</html>