﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master"
    AutoEventWireup="false" CodeFile="changepassword.aspx.vb"
    Inherits="changepassword" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h1>Change Password</h1>

    <asp:Label ID="Label1" runat="server"
        Text="Current Password"></asp:Label>

    <br />

    <asp:TextBox ID="TextBox1" runat="server"
        TextMode="Password"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label2" runat="server"
        Text="New Password"></asp:Label>

    <br />

    <asp:TextBox ID="TextBox2" runat="server"
        TextMode="Password"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label3" runat="server"
        Text="Confirm New Password"></asp:Label>

    <br />

    <asp:TextBox ID="TextBox3" runat="server"
        TextMode="Password"></asp:TextBox>

    <br /><br />

    <asp:Button ID="Button1" runat="server"
        Text="Change Password" />

</asp:Content>