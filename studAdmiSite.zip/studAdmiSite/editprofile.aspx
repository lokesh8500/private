﻿<%@ Page Title="" Language="VB" MasterPageFile="~/MasterPage.master"
    AutoEventWireup="false" CodeFile="editprofile.aspx.vb"
    Inherits="editprofile" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <h1>Edit Profile</h1>

    <asp:Label ID="Label1" runat="server" Text="Name"></asp:Label>
    <br />
    <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label2" runat="server" Text="Email"></asp:Label>
    <br />
    <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label3" runat="server" Text="Mobile"></asp:Label>
    <br />
    <asp:TextBox ID="TextBox3" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label4" runat="server" Text="Address"></asp:Label>
    <br />
    <asp:TextBox ID="TextBox4" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label5" runat="server" Text="City"></asp:Label>
    <br />
    <asp:TextBox ID="TextBox5" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label6" runat="server" Text="State"></asp:Label>
    <br />
    <asp:TextBox ID="TextBox6" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Label ID="Label7" runat="server" Text="Marks"></asp:Label>
    <br />
    <asp:TextBox ID="TextBox7" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Button ID="Button1" runat="server" Text="Update Profile" />

</asp:Content>
