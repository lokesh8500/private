﻿<%@ Page Language="VB"
    MasterPageFile="~/MasterPage.master"
    AutoEventWireup="false"
    CodeFile="addemp.aspx.vb"
    Inherits="addemp"
    Title="Add Employee" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="head"
    Runat="Server">
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="ContentPlaceHolder1"
    Runat="Server">

    <h2>Add Employee</h2>

    Employee ID:
    <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>

    <br /><br />

    Employee Name:
    <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>

    <br /><br />

    Mobile No:
    <asp:TextBox ID="TextBox3" runat="server"></asp:TextBox>

    <br /><br />

    Date of Birth:
    <asp:TextBox ID="TextBox4" runat="server"></asp:TextBox>

    <br /><br />

    Date of Joining:
    <asp:TextBox ID="TextBox5" runat="server"></asp:TextBox>

    <br /><br />

    City:
    <asp:TextBox ID="TextBox6" runat="server"></asp:TextBox>

    <br /><br />

    Salary:
    <asp:TextBox ID="TextBox7" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Button ID="Button1"
        runat="server"
        Text="Add Employee" />

</asp:Content>