﻿<%@ Page Language="VB"
    MasterPageFile="~/MasterPage.master"
    AutoEventWireup="false"
    CodeFile="home.aspx.vb"
    Inherits="home"
    Title="Home" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="head"
    Runat="Server">
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="ContentPlaceHolder1"
    Runat="Server">

    <h2>Welcome to Employee Management System</h2>

    <asp:Label ID="Label1"
        runat="server">
    </asp:Label>

    <br /><br />

    <p>Select an option from the menu.</p>

</asp:Content>