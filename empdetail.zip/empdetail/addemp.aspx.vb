﻿Imports System.Data.SqlClient

Partial Class addemp
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\empdetail\App_Data\Databaseemp.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("insert into emp_data(empid,ename,mobileno,dob,doj,city,salary) values(@empid,@ename,@mobileno,@dob,@doj,@city,@salary)", cn)

        cmd.Parameters.AddWithValue("@empid", TextBox1.Text)
        cmd.Parameters.AddWithValue("@ename", TextBox2.Text)
        cmd.Parameters.AddWithValue("@mobileno", TextBox3.Text)
        cmd.Parameters.AddWithValue("@dob", TextBox4.Text)
        cmd.Parameters.AddWithValue("@doj", TextBox5.Text)
        cmd.Parameters.AddWithValue("@city", TextBox6.Text)
        cmd.Parameters.AddWithValue("@salary", TextBox7.Text)

        cn.Open()

        cmd.ExecuteNonQuery()

        cn.Close()

        MsgBox("Employee added successfully")

    End Sub

End Class