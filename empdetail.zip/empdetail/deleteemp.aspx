﻿<%@ Page Language="VB"
    MasterPageFile="~/MasterPage.master"
    AutoEventWireup="false"
    CodeFile="deleteemp.aspx.vb"
    Inherits="deleteemp"
    Title="Delete Employee" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="head"
    Runat="Server">
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="ContentPlaceHolder1"
    Runat="Server">

    <h2>Delete Employee</h2>

    Employee ID:
    <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>

    <br /><br />

    <asp:Button ID="Button1"
        runat="server"
        Text="Delete Employee" />

</asp:Content>