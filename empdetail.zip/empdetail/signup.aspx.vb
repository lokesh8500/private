﻿Imports System.Data.SqlClient

Partial Class signup
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\empdetail\App_Data\Databaseemp.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("insert into user_login(username,mobileno,email,password) values(@username,@mobileno,@email,@password)", cn)

        cmd.Parameters.AddWithValue("@username", TextBox1.Text)
        cmd.Parameters.AddWithValue("@mobileno", TextBox2.Text)
        cmd.Parameters.AddWithValue("@email", TextBox3.Text)
        cmd.Parameters.AddWithValue("@password", TextBox4.Text)

        cn.Open()

        cmd.ExecuteNonQuery()

        cn.Close()

        MsgBox("Signup successful")

        Response.Redirect("login.aspx")

    End Sub

End Class