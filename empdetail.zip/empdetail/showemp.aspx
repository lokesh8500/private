﻿<%@ Page Language="VB"
    MasterPageFile="~/MasterPage.master"
    AutoEventWireup="false"
    CodeFile="showemp.aspx.vb"
    Inherits="showemp"
    Title="Show Employees" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="head"
    Runat="Server">
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="ContentPlaceHolder1"
    Runat="Server">

    <h2>Employee Details</h2>

    <asp:GridView ID="GridView1"
        runat="server"
        AutoGenerateColumns="True">
    </asp:GridView>

</asp:Content>