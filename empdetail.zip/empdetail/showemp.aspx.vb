﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class showemp
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Not IsPostBack Then
            showdata()
        End If

    End Sub

    Sub showdata()

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\empdetail\App_Data\Databaseemp.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("select * from emp_data", cn)

        Dim da As New SqlDataAdapter(cmd)

        Dim ds As New DataSet()

        da.Fill(ds)

        GridView1.DataSource = ds
        GridView1.DataBind()

    End Sub

End Class