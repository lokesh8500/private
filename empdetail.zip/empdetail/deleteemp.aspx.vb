﻿Imports System.Data.SqlClient

Partial Class deleteemp
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\empdetail\App_Data\Databaseemp.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("delete from emp_data where empid=@empid", cn)

        cmd.Parameters.AddWithValue("@empid", TextBox1.Text)

        cn.Open()

        Dim result As Integer = cmd.ExecuteNonQuery()

        cn.Close()

        If result > 0 Then

            MsgBox("Employee deleted successfully")

        Else

            MsgBox("Employee ID not found")

        End If

    End Sub

End Class