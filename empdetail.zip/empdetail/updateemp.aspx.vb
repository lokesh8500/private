﻿Imports System.Data.SqlClient

Partial Class updateemp
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\empdetail\App_Data\Databaseemp.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("update emp_data set ename=@ename,mobileno=@mobileno,dob=@dob,doj=@doj,city=@city,salary=@salary where empid=@empid", cn)

        cmd.Parameters.AddWithValue("@empid", TextBox1.Text)
        cmd.Parameters.AddWithValue("@ename", TextBox2.Text)
        cmd.Parameters.AddWithValue("@mobileno", TextBox3.Text)
        cmd.Parameters.AddWithValue("@dob", TextBox4.Text)
        cmd.Parameters.AddWithValue("@doj", TextBox5.Text)
        cmd.Parameters.AddWithValue("@city", TextBox6.Text)
        cmd.Parameters.AddWithValue("@salary", TextBox7.Text)

        cn.Open()

        Dim result As Integer = cmd.ExecuteNonQuery()

        cn.Close()

        If result > 0 Then

            MsgBox("Employee updated successfully")

        Else

            MsgBox("Employee ID not found")

        End If

    End Sub

End Class