﻿<%@ Page Language="VB" AutoEventWireup="false"
    CodeFile="login.aspx.vb" Inherits="login" %>

<!DOCTYPE html>

<html>
<head id="Head1" runat="server">
    <title>Employee Management - Login</title>
</head>

<body>

<form id="form1" runat="server">

    <h1>Login</h1>

    Username:
    <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>

    <br /><br />

    Password:
    <asp:TextBox ID="TextBox2" runat="server"
        TextMode="Password"></asp:TextBox>

    <br /><br />

    <asp:Button ID="Button1" runat="server"
        Text="Login" />

    <br /><br />

    <asp:HyperLink ID="HyperLink1" runat="server"
        NavigateUrl="signup.aspx">
        Create New Account
    </asp:HyperLink>

</form>

</body>
</html>