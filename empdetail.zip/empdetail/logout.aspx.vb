﻿Partial Class logout
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        Session.Clear()
        Session.Abandon()

        Response.Redirect("login.aspx")

    End Sub

End Class