﻿Imports System.Data.SqlClient

Partial Class login
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\empdetail\App_Data\Databaseemp.mdf;Integrated Security=True;User Instance=True")

        Dim cmd As New SqlCommand("select count(*) from user_login where username=@username and password=@password", cn)

        cmd.Parameters.AddWithValue("@username", TextBox1.Text)
        cmd.Parameters.AddWithValue("@password", TextBox2.Text)

        cn.Open()

        Dim result As Integer = cmd.ExecuteScalar()

        cn.Close()

        If result > 0 Then

            Session("username") = TextBox1.Text

            Response.Redirect("home.aspx")

        Else

            MsgBox("Invalid username or password")

        End If

    End Sub

End Class