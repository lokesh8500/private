﻿<%@ Page Language="VB" AutoEventWireup="false"
    CodeFile="signup.aspx.vb" Inherits="signup" %>

<!DOCTYPE html>

<html>
<head id="Head1" runat="server">
    <title>Employee Management - Signup</title>
</head>

<body>

<form id="form1" runat="server">

    <h1>Signup</h1>

    Username:
    <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>

    <br /><br />

    Mobile No:
    <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>

    <br /><br />

    Email:
    <asp:TextBox ID="TextBox3" runat="server"></asp:TextBox>

    <br /><br />

    Password:
    <asp:TextBox ID="TextBox4" runat="server"
        TextMode="Password"></asp:TextBox>

    <br /><br />

    <asp:Button ID="Button1" runat="server"
        Text="Signup" />

    <br /><br />

    <asp:HyperLink ID="HyperLink1" runat="server"
        NavigateUrl="login.aspx">
        Already have an account? Login
    </asp:HyperLink>

</form>

</body>
</html>