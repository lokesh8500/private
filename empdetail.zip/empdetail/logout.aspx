﻿<%@ Page Language="VB" AutoEventWireup="false"
    CodeFile="logout.aspx.vb" Inherits="logout" %>

<!DOCTYPE html>

<html>
<head id="Head1" runat="server">
    <title>Logout</title>
</head>

<body>

<form id="form1" runat="server">

    <h2>Logging out...</h2>

</form>

</body>
</html>