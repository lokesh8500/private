﻿Partial Class home
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        Label1.Text = "Welcome, " & Session("username").ToString()

    End Sub

End Class