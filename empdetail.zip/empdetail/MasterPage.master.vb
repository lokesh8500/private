﻿Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Session("username") Is Nothing Then

            Response.Redirect("login.aspx")

        End If

    End Sub

End Class