﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class student
    Inherits System.Web.UI.Page

    Dim con As String = "Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\student\App_Data\Databasestudent.mdf;Integrated Security=True;User Instance=True"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Not IsPostBack Then
            showdata()
        End If

    End Sub

    Sub showdata()

        Dim cn As New SqlConnection(con)

        Dim cmd As New SqlCommand("select * from student", cn)

        Dim da As New SqlDataAdapter(cmd)

        Dim ds As New DataSet()

        da.Fill(ds)

        GridView1.DataSource = ds
        GridView1.DataBind()

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        Dim cn As New SqlConnection(con)

        Dim cmd As New SqlCommand("insert into student values(@roll_no,@name,@course,@percentage)", cn)

        cmd.Parameters.AddWithValue("@roll_no", TextBox1.Text)
        cmd.Parameters.AddWithValue("@name", TextBox2.Text)
        cmd.Parameters.AddWithValue("@course", TextBox3.Text)
        cmd.Parameters.AddWithValue("@percentage", TextBox4.Text)

        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()

        MsgBox("Record inserted successfully")

        showdata()

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click

        Dim cn As New SqlConnection(con)

        Dim cmd As New SqlCommand("update student set percentage=@percentage where name=@name", cn)

        cmd.Parameters.AddWithValue("@percentage", TextBox6.Text)
        cmd.Parameters.AddWithValue("@name", TextBox5.Text)

        cn.Open()

        Dim result As Integer = cmd.ExecuteNonQuery()

        cn.Close()

        If result > 0 Then

            MsgBox("Percentage updated successfully")
            showdata()

        Else

            MsgBox("Student not found")

        End If

    End Sub

End Class