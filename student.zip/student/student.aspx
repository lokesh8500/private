﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="student.aspx.vb" Inherits="student" %>

<!DOCTYPE html>

<html>
<head id="Head1" runat="server">
    <title>Student Records</title>
</head>

<body>
<form id="form1" runat="server">

<h1>Student Record</h1>

Roll No:
<asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
<br /><br />

Name:
<asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
<br /><br />

Course:
<asp:TextBox ID="TextBox3" runat="server"></asp:TextBox>
<br /><br />

Percentage:
<asp:TextBox ID="TextBox4" runat="server"></asp:TextBox>
<br /><br />

<asp:Button ID="Button1" runat="server" Text="Insert Record" />

<hr />

<h2>Update Percentage</h2>

Student Name:
<asp:TextBox ID="TextBox5" runat="server"></asp:TextBox>
<br /><br />

New Percentage:
<asp:TextBox ID="TextBox6" runat="server"></asp:TextBox>
<br /><br />

<asp:Button ID="Button2" runat="server" Text="Update Percentage" />

<br /><br />

<asp:GridView ID="GridView1" runat="server"
    AutoGenerateColumns="True">
</asp:GridView>

</form>
</body>
</html>