﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=G:\asp\emp\App_Data\Database.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")
        Dim cmd As New SqlCommand("select count(username) from emp where username='" + TextBox1.Text + "'and password='" + TextBox2.Text + "'", cn)
        cn.Open()
        Dim count = cmd.ExecuteScalar
        cn.Close()
        If count > 0 Then
            Session("un") = TextBox1.Text
            Response.Redirect("~/search.aspx")
        Else
            MsgBox("invalid username or password")
        End If
    End Sub
End Class
