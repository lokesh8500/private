﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="Default.aspx.vb" Inherits="_Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Untitled Page</title>
    <style type="text/css">
        .style1
        {
            width: 48%;
            height: 149px;
        }
        .style2
        {
            width: 154px;
            text-align: center;
        }
        .style3
        {
            text-align: center;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
    <table align="center" class="style1">
        <tr>
            <td class="style2">
                <asp:Label ID="Label1" runat="server" Text="username"></asp:Label>
            </td>
            <td class="style3">
                <asp:TextBox ID="TextBox1" runat="server" Height="33px" 
                    style="margin-left: 0px" Width="233px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style2">
                <asp:Label ID="Label2" runat="server" Text="password"></asp:Label>
            </td>
            <td class="style3">
                <asp:TextBox ID="TextBox2" runat="server" Height="33px" Width="233px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td class="style2">
                <asp:LinkButton ID="LinkButton1" runat="server" PostBackUrl="register.aspx">new 
                user ?</asp:LinkButton>
            </td>
            <td class="style3">
                <asp:Button ID="Button1" runat="server" Text="LogIn" Width="154px" />
            </td>
        </tr>
    </table>
    </form>
</body>
</html>
