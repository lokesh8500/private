﻿<%@ Page Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="editprofile.aspx.vb" Inherits="Default2" title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
    .style3
    {
        width: 702px;
    }
    .style4
    {
        width: 611px;
    }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1" style="width: 79%">
    <tr>
        <td class="style3">
            address</td>
        <td class="style4">
            <asp:TextBox ID="TextBox1" runat="server" Width="420px"></asp:TextBox>
        </td>
    </tr>
    <tr>
        <td class="style3">
            city</td>
        <td class="style4">
            <asp:TextBox ID="TextBox2" runat="server" Width="420px"></asp:TextBox>
        </td>
    </tr>
    <tr>
        <td class="style3">
            state</td>
        <td class="style4">
            <asp:TextBox ID="TextBox3" runat="server" Width="420px"></asp:TextBox>
        </td>
    </tr>
    <tr>
        <td class="style3">
            mobile</td>
        <td class="style4">
            <asp:TextBox ID="TextBox4" runat="server" Width="420px"></asp:TextBox>
        </td>
    </tr>
    <tr>
        <td class="style3">
            email</td>
        <td class="style4">
            <asp:TextBox ID="TextBox5" runat="server" Width="420px"></asp:TextBox>
        </td>
    </tr>
    <tr>
        <td class="style3">
            last donate date</td>
        <td class="style4">
            <asp:TextBox ID="TextBox6" runat="server" Width="420px"></asp:TextBox>
        </td>
    </tr>
</table>
<asp:Button ID="Button1" runat="server" Text="Update Profile" Width="584px" />
</asp:Content>

