﻿<%@ Page Language="VB" MasterPageFile="~/MasterPage.master" AutoEventWireup="false" CodeFile="search.aspx.vb" Inherits="Default2" title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
    .style3
    {
        width: 161px;
    }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <table class="style1">
    <tr>
        <td colspan="2">
            search</td>
    </tr>
    <tr>
        <td class="style3">
            city</td>
        <td>
            <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" 
                DataSourceID="SqlDataSource1" DataTextField="city" DataValueField="city">
                <asp:ListItem>navsari</asp:ListItem>
                <asp:ListItem>surat</asp:ListItem>
                <asp:ListItem>valsad</asp:ListItem>
            </asp:DropDownList>
        </td>
    </tr>
    <tr>
        <td class="style3">
            state</td>
        <td>
            <asp:DropDownList ID="DropDownList2" runat="server" AutoPostBack="True" 
                DataSourceID="SqlDataSource1" DataTextField="state" DataValueField="state">
                <asp:ListItem>gujarat</asp:ListItem>
                <asp:ListItem>maharashtra</asp:ListItem>
                <asp:ListItem>delhi</asp:ListItem>
                <asp:ListItem>panjab</asp:ListItem>
            </asp:DropDownList>
        </td>
    </tr>
</table>
<p>
    <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
        ConnectionString="<%$ ConnectionStrings:DatabaseConnectionString %>" 
        SelectCommand="SELECT * FROM [emp]"></asp:SqlDataSource>
</p>
</asp:Content>

