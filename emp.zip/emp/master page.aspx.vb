﻿
Partial Class master_page
    Inherits System.Web.UI.Page

End Class
